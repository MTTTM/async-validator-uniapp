import Vue from 'vue';
let t= new Vue();
export default t;